/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usekambaintern;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author JohnBengui
 */
public class HttpJsonPostRequest 
{
    
    private static final String URL_CONNECTION = "https://kamba-api-staging.herokuapp.com/v1/transactions";
    private static final String METHOD = "POST";
    private static final String CONTENT_TYPE = "application/json";
    private static final String AUTHORIZATION_KEY = "7p2RbUyWWCq34cLd8QJJFQtt";
    private static final String RECEIVER_ID = "034562f8-8880-4fc9-9a48-e9f24d57c0e5";
    private static final int HTTP_STATUS_CREATED = 201;    
    
    public HttpJsonPostRequest() 
    {
        try 
        {
            sendRequestJson();
        } 
        catch (JSONException ex) {
            Logger.getLogger(HttpJsonPostRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Abrir a conexao http com a api
    private HttpURLConnection openConnection()
    {
        HttpURLConnection connection = null;
        
        try 
        {            
            URL url = new URL(URL_CONNECTION);
            
            connection = (HttpURLConnection) url.openConnection();            
            
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection.setRequestProperty("Authorization", "Token " + AUTHORIZATION_KEY);
            connection.setRequestProperty("Content-Type", CONTENT_TYPE);
            
            connection.setRequestMethod(METHOD);
                        
            connection.setDoInput(true);
            connection.setDoOutput(true);
            
        } catch (IOException ex) 
        {
            Logger.getLogger(HttpJsonPostRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            return connection;
        }
    }
    
    //Envia a requisicao post
    private void sendRequestJson() throws JSONException
    {
        try 
        {
            HttpURLConnection connection = openConnection();
            
            JSONObject jsonRequest = new JSONObject();
            
            jsonRequest.put("receiver_id",RECEIVER_ID);
            jsonRequest.put("description","Pagamento");
            jsonRequest.put("amount",readAmount());
            
            DataOutputStream dataOutputStream = new DataOutputStream(connection.getOutputStream());
            dataOutputStream.writeBytes(jsonRequest.toString());
            
            dataOutputStream.flush();
            dataOutputStream.close();
            
            int status = connection.getResponseCode();
            
            System.out.println("HTTP CONNECTION STATUS " + status + " " + connection.getResponseMessage());
            
            if (status == HTTP_STATUS_CREATED)
            {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                
                while ((inputLine = bufferedReader.readLine()) != null) 
                {
                   response.append(inputLine);
                }

                JSONObject jsonResponse = new JSONObject(response.toString());
                
                String out = "";
                
                out += "\n id:" + jsonResponse.get("id");
                out += "\n intent:" + jsonResponse.get("intent");
                out += "\n subtotal:" + jsonResponse.get("subtotal");
                out += "\n fee:" + jsonResponse.get("fee");
                
                out += "\n from.id:" + jsonResponse.getJSONObject("from").getString("id");
                out += "\n from.firstname:" + jsonResponse.getJSONObject("from").getString("firstname");
                out += "\n from.lastname:" + jsonResponse.getJSONObject("from").getString("lastname");
                out += "\n from.phone_number:" + jsonResponse.getJSONObject("from").getString("phone_number");
                out += "\n from.email:" + jsonResponse.getJSONObject("from").getString("email");
                
                out += "\n to.id:" + jsonResponse.getJSONObject("to").getString("id");
                out += "\n to.firstname:" + jsonResponse.getJSONObject("to").getString("firstname");
                out += "\n to.lastname:" + jsonResponse.getJSONObject("to").getString("lastname");
                out += "\n to.phone_number:" + jsonResponse.getJSONObject("to").getString("phone_number");
                out += "\n to.email:" + jsonResponse.getJSONObject("to").getString("email");
                
                out += "\n description:" + jsonResponse.get("description");
                out += "\n transaction_type:" + jsonResponse.get("transaction_type");
                out += "\n status:" + jsonResponse.get("status");
                out += "\n created_at:" + jsonResponse.get("created_at");

                
                System.out.println(out);
                
                bufferedReader.close();
                connection.disconnect();
            }
        } 
        catch (IOException ex) 
        {
            Logger.getLogger(HttpJsonPostRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Lê o montante
    private int readAmount()
    {
        int amount = 0;
        
        try 
        {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("Entre com o montante");
            amount = Integer.parseInt(in.readLine());
        } 
        catch (Exception e) 
        {
            System.err.println("Erro ao ler o montante");
        }
        finally
        {
            return amount;
        }
    }
    
}
